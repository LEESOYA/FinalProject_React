import React from 'react';

function HomePage() {

  return (
    <div>
      상품등록
    </div>
  );
}
export default HomePage; 