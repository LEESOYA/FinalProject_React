import React, { Component } from 'react';

class MemberManagePage extends Component {
  render() {
    return (
      <div>
        회원관리 페이지?
      </div>
    );
  }
}

export default MemberManagePage;