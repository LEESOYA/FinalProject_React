import React, { Component } from 'react';

class ProductOrderConfirmPage extends Component {
  render() {
    return (
      <div>
        주문관리 페이지
      </div>
    );
  }
}

export default ProductOrderConfirmPage;